<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD>
<TITLE> New Document </TITLE>
<META NAME="Generator" CONTENT="EditPlus">
<META NAME="Author" CONTENT="">
<META NAME="Keywords" CONTENT="">
<META NAME="Description" CONTENT="">
</HEAD>

<BODY>

<?php
	require_once('auth.php');
?>

<h1>helllllllllo user we</h1>

<h2>Welcome <?php echo $_SESSION['username'];?>! To The Administrator's System Management</h2>

<A HREF="logout.php">LOGOUT</A>

</BODY>
</HTML>
