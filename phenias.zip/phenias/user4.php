

<?php
session_register("names"); ?>

WELCOME USER 4